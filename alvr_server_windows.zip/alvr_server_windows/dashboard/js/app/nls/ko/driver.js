define({
    noDrivers: "등록된 드라이버 없음",
    registeredDrivers: "등록된 드라이버",
    removeDriver: "제거하기",
    driverUnregisterSuccessful: "드라이버 제거 완료",
    driverUnregisterFailed: "드라이버 제거 실패",
    registerAlvrDriver: "ALVR 드라이버 등록하기",
    registerAlvrDriverSuccess: "드라이버 등록 완료",
    driverNotice:
        "드라이버 등록은 SteamVR 실행 혹은 풀트래킹을 위한 <a target= '_blank' href='https://www.driver4vr.com/'>Driver4VR</a> 같은 다른 SteamVR 드라이버와 함께 사용하는 경우에 필요합니다.",
});
