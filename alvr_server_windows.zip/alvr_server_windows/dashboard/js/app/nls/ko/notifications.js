define({
    "statistics.title": "상태",
    "statistics.msg": "상태 정보 확인가능",
});
