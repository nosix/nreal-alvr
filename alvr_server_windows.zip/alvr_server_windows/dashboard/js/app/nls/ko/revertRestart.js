define({
    // Revert Popup
    confirmRevertTitle: "설정 초기화",
    okRevertButton: "확인",
    cancelRevertButton: "취소",
    revertText: "기본값으로 초기화하시겠습니까?",
    // Restart Popup
    confirmRestartTitle: "SteamVr 재시작",
    restartText: "SteanVr을 재시작하시겠습니까? 현재 작동중인 VR프로그램이 종료됩니다.",
    dontAskRestart: "다시 묻지말기",
    okRestartButton: "확인",
    cancelRestartButton: "취소",
});
