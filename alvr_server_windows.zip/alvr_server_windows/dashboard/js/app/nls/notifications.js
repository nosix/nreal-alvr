define({
    root: {
        "statistics.title": "Statistics",
        "statistics.msg": "Statistics information available",
    },
    it: true,
    sl: true,
    es: true,
    fr: true,
    ja: true,
    zh: true,
    ru: true,
    bg: true,
    de: true,
    nl: true,
    ko: true,
});
