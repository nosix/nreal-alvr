define({
    "statistics.title": "状态信息",
    "statistics.msg": "已获得状态信息",
});
