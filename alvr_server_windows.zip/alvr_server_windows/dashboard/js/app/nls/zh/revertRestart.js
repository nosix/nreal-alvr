define({
    // Revert Popup
    confirmRevertTitle: "还原设定?",
    okRevertButton: "确认",
    cancelRevertButton: "取消",
    revertText: "将属性还原为默认值",
    // Restart Popup
    confirmRestartTitle: "重启SteamVR?",
    restartText: "重启SteamVR?这将关闭当前正在运行的VR程序",
    dontAskRestart: "不在询问我",
    okRestartButton: "是",
    cancelRestartButton: "否",
});
