define({
    // "statistics.title": "",
    // "statistics.msg": "",
});
