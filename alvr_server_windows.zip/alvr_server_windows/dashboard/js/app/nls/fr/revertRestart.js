define({
    // Revert Popup
    confirmRevertTitle: "Restaurer paramètre ?",
    okRevertButton: "OK",
    cancelRevertButton: "Annuler",
    revertText: "Restaurer la valeur par défaut de",
    // Restart Popup
    confirmRestartTitle: "Relancer SteamVR ?",
    restartText: "Relancer SteamVR ? Cela va fermer toute application vr en cours",
    dontAskRestart: "Ne plus demander",
    okRestartButton: "OK",
    cancelRestartButton: "Annuler",
});
