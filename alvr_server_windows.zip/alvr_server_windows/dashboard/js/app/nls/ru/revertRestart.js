define({
    // Revert Popup
    confirmRevertTitle: "Восстановить параметр?",
    okRevertButton: "Да",
    cancelRevertButton: "Отмена",
    revertText: "Восстановить значение параметра к",
    // Restart Popup
    confirmRestartTitle: "Перезапустить SteamVR?",
    restartText: "Перезапустить SteamVR? Это закроет выполняемое VR-приложение",
    dontAskRestart: "Больше не спрашивать",
    okRestartButton: "Да",
    cancelRestartButton: "Отменить",
});
