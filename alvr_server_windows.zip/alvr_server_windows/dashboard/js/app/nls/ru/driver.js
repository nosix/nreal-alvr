define({
    noDrivers: "Нет зарегистрированных драйверов",
    registeredDrivers: "Зарегистрированные драйверы",
    removeDriver: "удалить",
    driverUnregisterSuccessful: "Драйвер успешно разрегистрирован",
    driverUnregisterFailed: "Разрегистрация драйвера не удалась",
    registerAlvrDriver: "Загрузить драйвер ALVR",
    registerAlvrDriverSuccess: "Драйвер успешно зарегистрирован",
    // "driverNotice": "",
});
