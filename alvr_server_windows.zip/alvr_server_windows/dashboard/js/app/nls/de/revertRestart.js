define({
    // Revert Popup
    confirmRevertTitle: "Einstellungen zurücksetzen?",
    okRevertButton: "OK",
    cancelRevertButton: "Abbrechen",
    revertText: "Setze die Eigenschaft zurück auf die Werte",
    // Restart Popup
    confirmRestartTitle: "SteamVR neustarten?",
    restartText: "SteamVR neustarten? Dies wird deine momentan ausgeführte VR-Applikation beenden",
    dontAskRestart: "Nicht erneut fragen",
    okRestartButton: "OK",
    cancelRestartButton: "Abbrechen",
});
