define({
    "statistics.title": "Statistiken",
    "statistics.msg": "Statistiken Information erhalten",
});
