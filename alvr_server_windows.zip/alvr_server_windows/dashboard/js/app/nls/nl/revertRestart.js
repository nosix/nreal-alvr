define({
    // Revert Popup
    confirmRevertTitle: "Deze instelling terugdraaien?",
    okRevertButton: "Ok",
    cancelRevertButton: "Annuleren",
    revertText: "Zet de instelling terug naar de standaardwaarden",
    // Restart Popup
    confirmRestartTitle: "SteamVR herstarten?",
    restartText: "SteamVR herstarten? Dit zal de huidig draaiende VR-Applicatie sluiten",
    dontAskRestart: "Niet meer opnieuw vragen",
    okRestartButton: "Ok",
    cancelRestartButton: "Annuleren",
});
