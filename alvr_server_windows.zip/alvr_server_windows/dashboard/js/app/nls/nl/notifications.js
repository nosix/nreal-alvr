define({
    "statistics.title": "Statistieken",
    "statistics.msg": "Statistiek informatie beschikbaar",
});
