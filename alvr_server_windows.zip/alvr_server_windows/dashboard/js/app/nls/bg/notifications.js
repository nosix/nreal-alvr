define({
    "statistics.title": "Статистика",
    "statistics.msg": "Получена статистическая информация",
});
