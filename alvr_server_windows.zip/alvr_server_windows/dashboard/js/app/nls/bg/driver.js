define({
    noDrivers: "Няма регистрирани драйвери",
    registeredDrivers: "Регистрирани драйвери",
    removeDriver: "Изтрий",
    driverUnregisterSuccessful: "Драйвер нерегистриран успешно",
    driverUnregisterFailed: "Отписване на драйвера не бе успешно",
    registerAlvrDriver: "Регистрираи ALVR драйвер",
    registerAlvrDriverSuccess: "Драйверът е регистриран успешно",
    // "driverNotice": "",
});
