define({
    // Revert Popup
    confirmRevertTitle: "Възстанови настройки?",
    okRevertButton: "Да",
    cancelRevertButton: "Отмяна",
    revertText: "Възстановете стойността на параметъра на",
    // Restart Popup
    confirmRestartTitle: "Рестартирайте SteamVR?",
    restartText: "Рестартирайте SteamVR? Това ще затвори работещото VR-приложение",
    dontAskRestart: "Не питай повече",
    okRestartButton: "Да",
    cancelRestartButton: "Отмяна",
});
