define({
    // Revert Popup
    confirmRevertTitle: "設定の初期化",
    okRevertButton: "OK",
    cancelRevertButton: "キャンセル",
    revertText: "この設定をデフォルトの値に戻しますか",
    // Restart Popup
    confirmRestartTitle: "SteamVRの再起動",
    restartText: "SteamVRを再起動しますか？実行中のVRアプリを終了します.",
    dontAskRestart: "今後, このメッセージを表示しない",
    okRestartButton: "OK",
    cancelRestartButton: "キャンセル",
});
