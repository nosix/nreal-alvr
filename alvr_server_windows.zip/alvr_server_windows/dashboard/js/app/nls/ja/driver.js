define({
    noDrivers: "登録されたドライバはありません",
    registeredDrivers: "登録ドライバ",
    removeDriver: "削除",
    driverUnregisterSuccessful: "ドライバの削除が完了しました",
    driverUnregisterFailed: "ドライバの削除に失敗しました",
    registerAlvrDriver: "ALVRドライバを登録",
    registerAlvrDriverSuccess: "ドライバの登録が完了しました",
    driverNotice:
        "重要：ドライバーの登録は通常お勧めしません。今、ドライバの登録は、SteamVRを単独で起動する場合、またはALVRを他のSteamVRドライバー（全身追跡用の <a target= '_blank' href='https://www.driver4vr.com/'>Driver4VR</a> など）と一緒に使用する場合のみです。",
});
