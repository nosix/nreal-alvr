define({
    noDrivers: "Nessun driver registrato",
    registeredDrivers: "Driver registrati",
    removeDriver: "Rimuovi",
    driverUnregisterSuccessful: "Rimozione della registrazione del driver completata",
    driverUnregisterFailed: "Rimozione della registrazione fallita",
    registerAlvrDriver: "Registra il driver di ALVR",
    registerAlvrDriverSuccess: "Driver registrato con successo",
    // "driverNotice": "",
});
