define({
    // Revert Popup
    confirmRevertTitle: "Reimpostare valore?",
    okRevertButton: "OK",
    cancelRevertButton: "Annulla",
    revertText: "Ripristinare impostazione al suo valore predefinito, cioè ",
    // Restart Popup
    confirmRestartTitle: "Riavviare SteamVR?",
    restartText: "Riavviare SteamVR? Questo chiuderà l'app/gioco aperto al momento",
    dontAskRestart: "Non chiedere più",
    okRestartButton: "OK",
    cancelRestartButton: "Annulla",
});
