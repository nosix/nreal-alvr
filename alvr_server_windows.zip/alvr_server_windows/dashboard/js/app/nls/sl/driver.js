define({
    noDrivers: "Ni nameščenih vmesnikov",
    registeredDrivers: "Nameščeni vmesniki",
    removeDriver: "ODSTRANI",
    driverUnregisterSuccessful: "Vmesnik vspešno odstranjen",
    driverUnregisterFailed: "Odstranvevanje vmesnika ni vspelo",
    registerAlvrDriver: "NAMESTI ALVR VMESNIK",
    registerAlvrDriverSuccess: "Vmesnik vspešno nameščen",
    driverNotice:
        "POMEMBNO: Od ALVR različice v13.1.0, nameščanje vmesnika ni priporočeno. Sedaj je namestitev vmesnika potrebna samo ko želiš zagnati SteamVR samega po sebi, ali pa ko želiš uporabljati ALVR skupaj z drugimim SteamVR vmesniki, kot <a target= '_blank' href='https://www.driver4vr.com/'>Driver4VR</a> za sledenje celotnega telesa.",
});
