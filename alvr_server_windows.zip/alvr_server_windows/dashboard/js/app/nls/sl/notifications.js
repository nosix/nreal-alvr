define({
    "statistics.title": "Podrobnosti",
    "statistics.msg": "Podrobnosti so na voljo",
});
