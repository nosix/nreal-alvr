define({
    // Revert Popup
    confirmRevertTitle: "Povrni nastavitve?",
    okRevertButton: "VREDU",
    cancelRevertButton: "PREKLIČI",
    revertText: "Povrni nastavitev na pred-nastavljeno vsoto",
    // Restart Popup
    confirmRestartTitle: "Ponovno zaženi SteamVR?",
    restartText: "Ponovno zaženi SteamVR? To bo ugasnilo trenutno tekoče VR zadeve",
    dontAskRestart: "Ne vprašaj več",
    okRestartButton: "VREDU",
    cancelRestartButton: "PREKLIČI",
});
