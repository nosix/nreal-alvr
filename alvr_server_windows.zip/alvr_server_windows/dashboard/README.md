# Description
This folder contains the web-application that is used as UI for ALVR.

Its based on the libraries Bootstrap 4, jquery and RequireJS. It was a deliberate choice not to use a more modern framework lien (react etc. ) for the following reasons:
-   does not require nodejs, neither to build, nor to run  
-   easy to read, non minified code  
-   speed is not a requirement for the ui  
-   proven and stable libraries are used
